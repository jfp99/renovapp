import { type Page, expect } from '@playwright/test';

/** Wipe browser storage so a test starts from a known, empty app. */
export async function resetBrowser(page: Page) {
  await page.goto('/');
  await page.evaluate(async () => {
    localStorage.clear();
    const dbs = (await indexedDB.databases?.()) ?? [];
    await Promise.all(
      dbs.map((db) => db.name && new Promise((res) => {
        const req = indexedDB.deleteDatabase(db.name!);
        req.onsuccess = req.onerror = req.onblocked = () => res(null);
      }))
    );
  });
}

/** Seed the stores directly — faster and less brittle than driving the canvas. */
export async function seedProject(page: Page, data: Record<string, unknown>) {
  await page.goto('/');
  await page.evaluate((payload) => {
    Object.entries(payload).forEach(([key, state]) => {
      localStorage.setItem(key, JSON.stringify({ state, version: 0 }));
    });
  }, data);
}

export const CATALOG = [
  { id: 'c-bunk', name: 'Lit superposé', category: 'bed', defaultWidth: 90, defaultHeight: 200, color: '#B4552F' },
  { id: 'c-single', name: 'Lit simple', category: 'bed', defaultWidth: 90, defaultHeight: 200, color: '#C97A55' },
];

export const ROOMS = [
  { id: 'r1', floorId: 'f1', name: 'CHAMBRE 1', type: 'bedroom', x: 0, y: 0, width: 320, height: 260, color: '#F0DDC9', doors: [], windows: [] },
];

export const PLACEMENTS = [
  { id: 'p1', roomId: 'r1', catalogItemId: 'c-bunk', x: 10, y: 10, rotation: 0, width: 90, height: 200 },
  { id: 'p2', roomId: 'r1', catalogItemId: 'c-single', x: 120, y: 10, rotation: 0, width: 90, height: 200 },
];

/** A bunk sleeps two, a single sleeps one — three places from two beds. */
export const EXPECTED_BEDS = 3;

export function baseProject() {
  return {
    'renovapp-plans': { floors: [{ id: 'f1', name: 'Rez-de-chaussée', order: 0 }], rooms: ROOMS },
    'renovapp-furniture': { placements: PLACEMENTS, catalog: CATALOG },
  };
}

/** Wait for the autosave indicator to confirm a write reached the disk. */
export async function waitForAutosave(page: Page) {
  await expect(page.locator('text=/Sauvegard(é|e)/i').first()).toBeVisible({ timeout: 20_000 });
}
